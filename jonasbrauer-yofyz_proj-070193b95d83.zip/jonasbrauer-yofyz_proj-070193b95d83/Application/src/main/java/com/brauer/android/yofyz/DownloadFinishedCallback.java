package com.brauer.android.yofyz;

public interface DownloadFinishedCallback {

    void finished();

}
