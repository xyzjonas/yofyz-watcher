
Yofyz android app
===================================

Goal:
 * background service polling yoga schedule HTML
 * internal storage remembering last state
 * notification pops-up every time there is an update (user configurable)
 * UI displays classes & enables filters config